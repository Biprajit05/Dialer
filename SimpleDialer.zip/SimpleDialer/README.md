# Simple Dialer

A bare-bones Android phone app: dial pad, call, and an in-call screen
(mute, hold, keypad, speaker, end). No contacts, no call history.

## Build
Open this folder in Android Studio and press Run, or use `gradle assembleDebug`.

## First use
Tap the green call button once. Android asks you to make Dialer your default
phone app (required to show your own call screen), then asks for call permission.
