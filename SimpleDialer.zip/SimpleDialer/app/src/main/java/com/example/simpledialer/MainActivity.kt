package com.example.simpledialer

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val number = StringBuilder()
    private lateinit var display: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0B0D")
        window.navigationBarColor = Color.parseColor("#0B0B0D")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#0B0B0D"))
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }

        display = TextView(this).apply {
            textSize = 36f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 1
        }
        root.addView(display, LinearLayout.LayoutParams(-1, 0, 1f))

        val keys = listOf(
            listOf("1", "2", "3"), listOf("4", "5", "6"),
            listOf("7", "8", "9"), listOf("*", "0", "#")
        )
        for (r in keys) {
            val row = row()
            for (k in r) row.addView(key(k) { add(k) }.also { v ->
                if (k == "0") v.setOnLongClickListener { add("+"); true }
            })
            root.addView(row)
        }

        val last = row()
        last.addView(spacer())
        last.addView(circle("\u2706", Color.parseColor("#1F8F5F")) { callPressed() })
        last.addView(circle("\u232B", Color.TRANSPARENT) { back() }.also {
            it.setOnLongClickListener { number.clear(); refresh(); true }
        })
        root.addView(last)

        setContentView(root)
        intent?.data?.schemeSpecificPart?.let { number.append(it) }
        refresh()
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
    }

    private fun spacer() = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(76), dp(76)).apply { setMargins(dp(14), dp(8), dp(14), dp(8)) }
    }

    private fun circle(label: String, bg: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 28f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = oval(bg)
        isClickable = true
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(dp(76), dp(76)).apply { setMargins(dp(14), dp(8), dp(14), dp(8)) }
    }

    private fun key(label: String, onClick: () -> Unit) =
        circle(label, Color.parseColor("#2A2A2E"), onClick)

    private fun add(c: String) { if (number.length < 20) number.append(c); refresh() }
    private fun back() { if (number.isNotEmpty()) number.deleteCharAt(number.length - 1); refresh() }
    private fun refresh() { display.text = number.toString() }

    @SuppressLint("MissingPermission")
    private fun callPressed() {
        if (number.isEmpty()) return
        val tm = getSystemService(TelecomManager::class.java)
        if (tm.defaultDialerPackage != packageName) {
            // Android asks once: "Set Dialer as your default phone app?"
            val rm = getSystemService(RoleManager::class.java)
            startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 1)
            return
        }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 2)
            return
        }
        tm.placeCall(Uri.fromParts("tel", number.toString(), null), Bundle())
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) callPressed()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 2 && results.firstOrNull() == PackageManager.PERMISSION_GRANTED) callPressed()
    }
}
