package com.example.simpledialer

import android.content.Intent
import android.telecom.Call
import android.telecom.InCallService

/** Holds the one active call so the UI can read it. */
object CallManager {
    var call: Call? = null
    var service: InCallService? = null
}

class CallService : InCallService() {
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.service = this
        CallManager.call = call
        startActivity(
            Intent(this, CallActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        if (CallManager.call == call) CallManager.call = null
    }
}
