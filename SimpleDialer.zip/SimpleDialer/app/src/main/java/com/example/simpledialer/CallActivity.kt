package com.example.simpledialer

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class CallActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var numberView: TextView
    private lateinit var controls: LinearLayout
    private lateinit var ringing: LinearLayout
    private lateinit var keypad: LinearLayout
    private lateinit var muteC: TextView
    private lateinit var holdC: TextView
    private lateinit var speakerC: TextView
    private var muted = false
    private var speaker = false

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call?, state: Int) = refresh()
    }
    private val tick = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }

    private val off = Color.parseColor("#2A2A2E")
    private val on = Color.parseColor("#5B5BD6")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun oval(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.parseColor("#0B0B0D")
        window.navigationBarColor = Color.parseColor("#0B0B0D")

        val call = CallManager.call ?: run { finish(); return }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#0B0B0D"))
            setPadding(dp(16), dp(72), dp(16), dp(32))
        }

        status = TextView(this).apply { textSize = 20f; setTextColor(Color.parseColor("#B0B0B8")); gravity = Gravity.CENTER }
        numberView = TextView(this).apply { textSize = 36f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(numberView, LinearLayout.LayoutParams(-1, -2))
        root.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))

        // Incoming call: answer / decline
        ringing = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        ringing.addView(item("\u2706", "Decline", Color.parseColor("#B3302A")) { CallManager.call?.reject(false, null) }.first)
        ringing.addView(item("\u2706", "Answer", Color.parseColor("#1F8F5F")) { CallManager.call?.answer(0) }.first)
        root.addView(ringing)

        // In-call controls
        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val mute = item("\uD83C\uDF99", "Mute", off) {
            muted = !muted
            CallManager.service?.setMuted(muted)
            muteC.background = oval(if (muted) on else off)
        }
        muteC = mute.second
        val hold = item("\u23F8", "Hold", off) {
            val c = CallManager.call ?: return@item
            if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()
        }
        holdC = hold.second
        controls.addView(row(mute.first, hold.first))

        val keypadBtn = item("\u2328", "Keypad", off) { showKeypad(true) }
        val end = item("\u2706", "", Color.parseColor("#B3302A")) {
            CallManager.call?.disconnect()
        }
        val spk = item("\uD83D\uDD0A", "Speaker", off) {
            speaker = !speaker
            CallManager.service?.setAudioRoute(
                if (speaker) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_WIRED_OR_EARPIECE
            )
            speakerC.background = oval(if (speaker) on else off)
        }
        speakerC = spk.second
        controls.addView(row(keypadBtn.first, end.first, spk.first))
        root.addView(controls)

        // DTMF keypad
        keypad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; visibility = View.GONE }
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("*", "0", "#")).forEach { r ->
            keypad.addView(row(*r.map { dtmfKey(it) }.toTypedArray()))
        }
        keypad.addView(row(item("\u2706", "", Color.parseColor("#B3302A")) { CallManager.call?.disconnect() }.first,
            item("\u2193", "Hide", off) { showKeypad(false) }.first))
        root.addView(keypad)

        setContentView(root)
        call.registerCallback(callback)
        tick.run()
    }

    private fun showKeypad(show: Boolean) {
        keypad.visibility = if (show) View.VISIBLE else View.GONE
        refresh()
    }

    private fun item(symbol: String, label: String, color: Int, onClick: () -> Unit): Pair<LinearLayout, TextView> {
        val circle = TextView(this).apply {
            text = symbol; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = oval(color); isClickable = true
            setOnClickListener { onClick() }
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            addView(circle, LinearLayout.LayoutParams(dp(76), dp(76)))
            addView(TextView(context).apply { text = label; textSize = 14f; setTextColor(Color.parseColor("#B0B0B8")); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) },
                LinearLayout.LayoutParams(-2, dp(24)))
        }
        return col to circle
    }

    private fun dtmfKey(c: String): View {
        val v = item(c, "", off) {}.first
        v.getChildAt(0).setOnTouchListener { _, e ->
            val call = CallManager.call
            when (e.action) {
                MotionEvent.ACTION_DOWN -> call?.playDtmfTone(c[0])
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> call?.stopDtmfTone()
            }
            true
        }
        return v
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
        views.forEach { addView(it) }
    }

    private fun refresh() {
        val c = CallManager.call
        if (c == null || c.state == Call.STATE_DISCONNECTED) { finish(); return }
        numberView.text = c.details.handle?.schemeSpecificPart ?: "Unknown"
        status.text = when (c.state) {
            Call.STATE_DIALING, Call.STATE_CONNECTING -> "Dialing\u2026"
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_ACTIVE -> {
                val start = c.details.connectTimeMillis
                val s = if (start > 0) ((System.currentTimeMillis() - start) / 1000).toInt() else 0
                "%02d:%02d".format(s / 60, s % 60)
            }
            else -> ""
        }
        val isRinging = c.state == Call.STATE_RINGING
        val keypadOpen = keypad.visibility == View.VISIBLE
        ringing.visibility = if (isRinging) View.VISIBLE else View.GONE
        controls.visibility = if (isRinging || keypadOpen) View.GONE else View.VISIBLE
        holdC.background = oval(if (c.state == Call.STATE_HOLDING) on else off)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        CallManager.call?.unregisterCallback(callback)
        super.onDestroy()
    }
}
